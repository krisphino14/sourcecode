<?php
    include "assets/knn/read-csv.php";
    $array_dataset = $array_dataset_csv;

    function getDataset(){
        global $array_dataset;
        return $array_dataset;
    }

    function countEuclidian($red_value, $green_value, $blue_value){
        global $array_dataset;
        //count euclidian distance every point dataset
        $number_dataset = sizeof($array_dataset); //number of dataset

        for($i=1; $i<$number_dataset; $i++){
            $penjumlahan = (pow($array_dataset[$i][0]-$red_value,2)) + (pow($array_dataset[$i][1]-$green_value,2)) + (pow($array_dataset[$i][2]-$blue_value,2));
            $euclidian = sqrt($penjumlahan);
            $array_euclidian[] = array('index_dataset'=>$i,'jarak'=>$euclidian);
        }
        
        //sorting array euclidian
        $columns = array_column($array_euclidian, 'jarak');
        array_multisort($columns, SORT_ASC, $array_euclidian);

        return $array_euclidian;
    }

    function resultKNN($array_euclidian){
        global $array_dataset;
        //get class deteksi
        $k = 15;
        $total_mentah = 0;
        $total_setengah_matang = 0;
        $total_matang = 0;
        for($i=0; $i<$k; $i++){
            $index = $array_euclidian[$i]['index_dataset'];
            //print_r($array_dataset[$index]);
            //echo $array_dataset[$index][3];
            if($array_dataset[$index][3] == "mentah"){
                $total_mentah++;
            }else if($array_dataset[$index][3] == "setengah matang"){
                $total_setengah_matang++;
            }else if($array_dataset[$index][3] == "matang"){
                $total_matang++;
            }
        }
        return array('mentah' => $total_mentah, 'setmatang'=> $total_setengah_matang, 'matang' => $total_matang);
    }
?>