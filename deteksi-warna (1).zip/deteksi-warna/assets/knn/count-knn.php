<?php
    include "knn.php";

    $red_value = $_POST['red'];
    $green_value = $_POST['green'];
    $blue_value = $_POST['blue'];

    function countKNN($red_value, $green_value, $blue_value){
        $euclidian_distance = countEuclidian($red_value, $green_value, $blue_value);
        $result_knn = resultKNN($euclidian_distance);
        $array_count_knn = $euclidian_distance;
        
        array_push($array_count_knn, $result_knn);
        echo json_encode($array_count_knn);
    }

    countKNN($red_value, $green_value, $blue_value);
?>