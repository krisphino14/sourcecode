<?php
include "knn.php";

$dataset = getDataset();
//print_r($dataset);
//echo "<pre>";
//echo var_dump($dataset);
//echo "</pre>"
echo json_encode(array("result" => $dataset));
?>