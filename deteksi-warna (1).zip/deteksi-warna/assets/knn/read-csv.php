<?php

if (($open = fopen("../dataset/data_ekstraksi_fitur.csv", "r")) !== FALSE){
	while (($data = fgetcsv($open, 1000, ",")) !== FALSE){		
	    $array_dataset_csv[] = $data;
	}
    fclose($open);
}
//echo "<pre>";
//To display array data
//var_dump($array_dataset);
//echo "</pre>";
