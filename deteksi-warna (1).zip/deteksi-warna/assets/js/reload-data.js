let last_sensor_timestamp = 0;

$(document).ready(function() {
    selesai();
});
 
function selesai() {
	setTimeout(function() {
        getDataSensor();
        selesai();
	}, 2000);
}

function getDataSensor() {
	$.getJSON("data/data-sensor.php", function(data) {
        let sensor_timestamp = data.result[0].timestamp;
        if(last_sensor_timestamp != sensor_timestamp){
            console.log(data);
            let dataset;
            last_sensor_timestamp = sensor_timestamp;
            console.log("berhasil");

            $.ajax({
                type: "GET",
                url: "assets/knn/get-dataset.php",
                dataType : "JSON",
                success: function (response) {
                    //console.log(response);
                    dataset = response.result;
                    $.ajax({
                        type: "POST",
                        url: "assets/knn/count-knn.php",
                        data: {
                            "red" : data.result[0].red,
                            "green" : data.result[0].green,
                            "blue" : data.result[0].blue,
                        },
                        dataType : "JSON",
                        success: function (response) {
                            setDataCountEuclidian(dataset, response);
                        }
                    });
                }
            });

            setDataToDataSensorCard(data);
        }
	});
}

function setDataToDataSensorCard(data){
    $("#data-sensor").empty();
    console.log(data.result);
    let content = "<p> red : "+data.result[0].red+
                  "</p>" +
                  "<p> green : "+data.result[0].green+
                  "</p>" + 
                  "<p> blue : "+data.result[0].blue+
                  "</p>";
    $("#data-sensor").append(content);

}

function setDataCountEuclidian(dataset, result_euclidian){
    $("#result-k-nearest").empty();
    console.log("ini fungsi set data");
    console.log(dataset[0]);
    console.log(result_euclidian[0]);

    let no = 1;
    let k = 15;
    for(i=0; i<k; i++){
        let content = "<tr>" +
                        "<td>"+no+"</td>" +
                        "<td>"+dataset[result_euclidian[i].index_dataset].r+"</td>" +
                        "<td>"+dataset[result_euclidian[i].index_dataset].g+"</td>" +
                        "<td>"+dataset[result_euclidian[i].index_dataset].b+"</td>" +
                        "<td>"+dataset[result_euclidian[i].index_dataset].label+"</td>" +
                        "<td>"+result_euclidian[i].jarak+"</td>" +
                      "</tr>";
        $("#result-k-nearest").append(content);
        no++;
    }

    //set result knn
    const data_length =  result_euclidian.length;
    $("#result-knn").empty();
    let content_knn = "<tr> <td>Mentah</td>"+
                       "<td>"+result_euclidian[data_length-1].mentah+"</td>"+
                       "</tr>"+
                       "<tr> <td>Setengah Matang</td>"+
                       "<td>"+result_euclidian[data_length-1].setmatang+"</td>"+
                       "</tr>"+
                       "<tr> <td>Matang</td>"+
                       "<td>"+result_euclidian[data_length-1].matang+"</td>"+
                       "</tr>";
    $("#result-knn").append(content_knn);

    //set final result knn
    $("#final-result-knn").html("Hasil Prediksi KNN : <b>"+result_euclidian[data_length-1].hasil_knn+"</b>");
}

function testjs(){
    console.log("testing");
    $("#data-sensor").html("yes");
}