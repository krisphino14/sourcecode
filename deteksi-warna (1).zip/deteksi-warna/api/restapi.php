<?php
require "../config/connection.php";

if(function_exists($_GET['function'])) {
    $_GET['function']();
}

ini_set('date.timezone', 'Asia/Kuala_Lumpur');
$now = new DateTime();
$datenow = $now->format("Y-m-d H:i:s");

function insert_data_sensor(){
    global $connect;   
    ini_set('date.timezone', 'Asia/Kuala_Lumpur');
    $now = new DateTime();
    $datenow = $now->format("Y-m-d H:i:s");
    
    /*data yang di kirim oleh server
        -id
        -red
        -green
        -blue
    */

    $check = array('id' => '', 'red' => '', 'green' => '', 'blue' => '');
    $check_match = count(array_intersect_key($_POST, $check));
    if($check_match == count($check)){

        $result = mysqli_query($connect, "INSERT INTO data_sensor SET
        id = '$_POST[id]',
        red = '$_POST[red]',
        green = '$_POST[green]',
        blue = '$_POST[blue]',
        timestamp = '$datenow'");
        
        if($result)
        {
            $response=array(
            'status' => 1,
            'message' =>'Insert Success'
            );
        }
        else
        {
            $response=array(
            'status' => 0,
            'message' =>'Insert Failed.'
            );
        }
    }else{
       $response=array(
                'status' => 0,
                'message' =>'Wrong Parameter In Insert Data Sensor'
             );
    }
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>