<?php require_once './app/templates/header.php'; ?>
        <div class="notif">
            <h5>Notifikasi tingkat kematangan buah mangga</h5>
            <div class="col-notif">
                <p>mangga masih mentah</p>
            </div>
        </div>
<?php require_once './app/templates/footer.php'; ?>