<?php
$host = "localhost";
$username = "root";
$pass = "";
$db_name = "db_deteksi_warna";

$connect = mysqli_connect($host, $username, $pass, $db_name);

if(!$connect){
    die("Failed connect to database :".mysqli_connect_error());
}

?>