<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--  link css lokal -->
    <link rel="stylesheet" href="./app/aset/css/landing.css">
    <!-- link css fontawessome -->
    <link rel="stylesheet" href="./app/aset/lib/fontawesome/css/all.css">
    <!-- title web aplication  -->
    <title>Sistem Monitoring Kematangan Mangga</title>
</head>
<body>
    <header>
        <section>
                <i class="fa-solid fa-bars"></i> <span>Main menu</span>
        </section>
        <ul>
            <li id="atas">
                <a href="index.php">
                    <i class="fa-solid fa-house"></i> <span>home</span>
                </a>
            </li>
            <li>
                <a href="tentang.php">
                    <i class="fa-solid fa-address-card"></i> <span>tentang aplikasi</span>
                </a>
            </li>
        </ul>
    </header>
    <main>
        <h1>sistem monitoring buah mangga</h1>
    