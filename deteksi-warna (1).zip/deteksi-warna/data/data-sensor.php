<?php
    include("../config/connection.php");
    $sql = mysqli_query($connect, "SELECT * FROM data_sensor ORDER BY timestamp DESC LIMIT 1");
    $result = array();
    
    while ($row = mysqli_fetch_assoc($sql)) {
        $data[] = $row;
    }
    $data = array_reverse($data);
    //print_r($data);
    echo json_encode(array("result" => $data));
?>